<?php include("header.php"); ?>
<?php include("menu.php"); ?>
<!-- CONTENT AREA -->
<div class="content-area">
<section class="page-section no-padding slider">
   <div class="container full-width">
      <div class="main-slider">
         <div class="owl-carousel" id="main-slider">
            <!-- Slide 2 -->
            <div class="item slide2 ver2">
               <div class="caption">
                  <div class="container">
                     <div class="div-table">
                        <div class="div-cell">
                           <div class="caption-content">
                              <p class="caption-text">
                                 ALL DISCOUNTS JUST FOR YOU
                              </p>
                              <h2 class="caption-subtitle">FIND BEST RETAL CARS</h2>
                              <p class="caption-text">
                                 <a class="btn btn-theme btn-theme-md" href="car-listing.php">See All Vehicles</a>
                              </p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- /Slide 2 -->
            <!-- Slide 1 -->
            <div class="item slide3 ver2">
               <div class="caption">
                  <div class="container">
                     <div class="div-table">
                        <div class="div-cell">
                           <div class="caption-content">
                              <h2 class="caption-title">100  luxury cars from multi brands are always available for you</h2>
                              <h3 class="caption-subtitle"><span>Now, Its easy for you rent a car</span></h3>
                              <p class="caption-text">
                                 <a class="btn btn-theme btn-theme-md" href="#">See All Vehicles</a>
                              </p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- /Slide 1 -->
            <!-- Slide 4 -->
            <div class="item slide4 ver4">
               <div class="caption">
                  <div class="container">
                     <div class="div-table">
                        <div class="div-cell">
                           <div class="caption-content">
                              <h2 class="caption-title">For rental Cars</h2>
                              <h3 class="caption-subtitle"><span>Best Deals</span></h3>
                              <p class="caption-text">
                                 Sales Up  %45 Off<br/>
                                 All Rental Cars Start from  49$
                              </p>
                              <p class="caption-text">
                                 <a class="btn btn-theme btn-theme-md" href="#">See All Vehicles</a>
                              </p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- /Slide 4 -->
         </div>
      </div>
   </div>
</section>
<!-- About Drive care -->
<section>
   <div class="space">
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <div class="heading">
                  <h2>Things you’ll love about Car Carry</h2>
                  <h5>Say no to empty seats.</h5>
               </div>
               <div class="row">
                  <div class="col-lg-12">
                     <ul class="cola-services">
                        <li data-aos="zoom-in" data-aos-duration="950" data-aos-delay="100" data-aos-once="true">
                           <figure>
                              <i class="flaticon-car"></i>
                           </figure>
                           <div class="services-meta">
                              <h4>you’re in control</h4>
                              <p>Verified member profiles & ratings mean you know exactly who you're travelling with.</p>
                           </div>
                        </li>
                        <li data-aos="zoom-in" data-aos-duration="950" data-aos-delay="100" data-aos-once="true">
                           <figure>
                              <i class="flaticon-handshake"></i>
                           </figure>
                           <div class="services-meta">
                              <h4>carpool with confidence</h4>
                              <p>ID verification adds another level of security to member profiles.</p>
                           </div>
                        </li>
                        <li data-aos="zoom-in" data-aos-duration="950" data-aos-delay="100" data-aos-once="true">
                           <figure>
                              <i class="flaticon-favorites"></i>
                           </figure>
                           <div class="services-meta">
                              <h4>ride fully insured</h4>
                              <p>We partner to cover your ride from start to finish, absolutely free of charge.</p>
                           </div>
                        </li>
                        <li style="padding: 44px;" data-aos="zoom-in" data-aos-duration="950" data-aos-delay="100" data-aos-once="true">
                           <figure>
                              <i class="flaticon-teacher-pointing-blackboard"></i>
                           </figure>
                           <div class="services-meta">
                              <h4>24/7 Car Support</h4>
                              <p>Call us at anywere at anytime.</p>
                           </div>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- cars list -->
<section class="page-section">
   <div class="container" data-aos="zoom-out" data-aos-duration="950" data-aos-delay="100" data-aos-once="true">
      <h2 class="section-title">
         <small>What a Kind of Car You Want</small>
         <span>Great Rental Offers for You</span>
      </h2>
      <div class="tabs">
         <ul id="tabs" class="nav">
            <!--
               -->
            <li class=""><a href="#tab-1" data-toggle="tab">Best Offers</a></li>
            <!--
               -->
            <li class="active"><a href="#tab-2" data-toggle="tab">Popular Cars</a></li>
            <!--
               -->
            <li class=""><a href="#tab-3" data-toggle="tab">Economic Cars</a></li>
         </ul>
      </div>
      <div class="tab-content">
         <!-- tab 1 -->
         <div class="tab-pane fade" id="tab-1">
            <div class="swiper swiper--offers-best">
               <div class="swiper-container">
                  <div class="swiper-wrapper">
                     <!-- Slides -->
                     <div class="swiper-slide">
                        <div class="thumbnail no-border no-padding thumbnail-car-card">
                           <div class="media">
                              <a class="media-link" data-gal="prettyPhoto" href="assets/img/preview/cars/car-370x220x1.jpg">
                              <img src="assets/img/preview/cars/car-370x220x1.jpg" alt=""/>
                              <span class="icon-view"><strong><i class="fa fa-eye"></i></strong></span>
                              </a>
                           </div>
                           <div class="caption text-center">
                              <h4 class="caption-title"><a href="contact.php">VW POLO TRENDLINE 2.0 TDI</a></h4>
                              <div class="caption-text">Start from 3000/per a day</div>
                              <div class="buttons">
                                 <a class="btn btn-theme" href="contact.php">Rent It</a>
                              </div>
                              <table class="table">
                                 <tr>
                                    <td><i class="fa fa-car"></i> 2013</td>
                                    <td><i class="fa fa-dashboard"></i> Diesel</td>
                                    <td><i class="fa fa-cog"></i> Auto</td>
                                    <td><i class="fa fa-road"></i> 25000</td>
                                 </tr>
                              </table>
                           </div>
                        </div>
                     </div>
                     <div class="swiper-slide">
                        <div class="thumbnail no-border no-padding thumbnail-car-card">
                           <div class="media">
                              <a class="media-link" data-gal="prettyPhoto" href="assets/img/preview/cars/car-370x220x2.jpg">
                              <img src="assets/img/preview/cars/car-370x220x2.jpg" alt=""/>
                              <span class="icon-view"><strong><i class="fa fa-eye"></i></strong></span>
                              </a>
                           </div>
                           <div class="caption text-center">
                              <h4 class="caption-title"><a href="contact.php">VW POLO TRENDLINE 2.0 TDI</a></h4>
                              <div class="caption-text">Start from 3500/per a day</div>
                              <div class="buttons">
                                 <a class="btn btn-theme" href="contact.php">Rent It</a>
                              </div>
                              <table class="table">
                                 <tr>
                                    <td><i class="fa fa-car"></i> 2013</td>
                                    <td><i class="fa fa-dashboard"></i> Diesel</td>
                                    <td><i class="fa fa-cog"></i> Auto</td>
                                    <td><i class="fa fa-road"></i> 25000</td>
                                 </tr>
                              </table>
                           </div>
                        </div>
                     </div>
                     <div class="swiper-slide">
                        <div class="thumbnail no-border no-padding thumbnail-car-card">
                           <div class="media">
                              <a class="media-link" data-gal="prettyPhoto" href="assets/img/preview/cars/car-370x220x3.jpg">
                              <img src="assets/img/preview/cars/car-370x220x3.jpg" alt=""/>
                              <span class="icon-view"><strong><i class="fa fa-eye"></i></strong></span>
                              </a>
                           </div>
                           <div class="caption text-center">
                              <h4 class="caption-title"><a href="contact.php">VW POLO TRENDLINE 2.0 TDI</a></h4>
                              <div class="caption-text">Start from 4000/per a day</div>
                              <div class="buttons">
                                 <a class="btn btn-theme" href="contact.php">Rent It</a>
                              </div>
                              <table class="table">
                                 <tr>
                                    <td><i class="fa fa-car"></i> 2013</td>
                                    <td><i class="fa fa-dashboard"></i> Diesel</td>
                                    <td><i class="fa fa-cog"></i> Auto</td>
                                    <td><i class="fa fa-road"></i> 25000</td>
                                 </tr>
                              </table>
                           </div>
                        </div>
                     </div>
                     <div class="swiper-slide">
                        <div class="thumbnail no-border no-padding thumbnail-car-card">
                           <div class="media">
                              <a class="media-link" data-gal="prettyPhoto" href="assets/img/preview/cars/car-370x220x4.jpg">
                              <img src="assets/img/preview/cars/car-370x220x4.jpg" alt=""/>
                              <span class="icon-view"><strong><i class="fa fa-eye"></i></strong></span>
                              </a>
                           </div>
                           <div class="caption text-center">
                              <h4 class="caption-title"><a href="contact.php">VW POLO TRENDLINE 2.0 TDI</a></h4>
                              <div class="caption-text">Start from 5000/per a day</div>
                              <div class="buttons">
                                 <a class="btn btn-theme" href="contact.php">Rent It</a>
                              </div>
                              <table class="table">
                                 <tr>
                                    <td><i class="fa fa-car"></i> 2013</td>
                                    <td><i class="fa fa-dashboard"></i> Diesel</td>
                                    <td><i class="fa fa-cog"></i> Auto</td>
                                    <td><i class="fa fa-road"></i> 25000</td>
                                 </tr>
                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="swiper-button-next"><i class="fa fa-angle-right"></i></div>
               <div class="swiper-button-prev"><i class="fa fa-angle-left"></i></div>
            </div>
         </div>
         <!-- tab 2 -->
         <div class="tab-pane fade active in" id="tab-2">
            <div class="swiper swiper--offers-popular">
               <div class="swiper-container">
                  <div class="swiper-wrapper">
                     <!-- Slides -->
                     <div class="swiper-slide">
                        <div class="thumbnail no-border no-padding thumbnail-car-card">
                           <div class="media">
                              <a class="media-link" data-gal="prettyPhoto" href="assets/img/preview/cars/car-370x220x3.jpg">
                              <img src="assets/img/preview/cars/car-370x220x3.jpg" alt=""/>
                              <span class="icon-view"><strong><i class="fa fa-eye"></i></strong></span>
                              </a>
                           </div>
                           <div class="caption text-center">
                              <h4 class="caption-title"><a href="contact.php">VW POLO TRENDLINE 2.0 TDI</a></h4>
                              <div class="caption-text">Start from 2800/per a day</div>
                              <div class="buttons">
                                 <a class="btn btn-theme" href="contact.php">Rent It</a>
                              </div>
                              <table class="table">
                                 <tr>
                                    <td><i class="fa fa-car"></i> 2013</td>
                                    <td><i class="fa fa-dashboard"></i> Diesel</td>
                                    <td><i class="fa fa-cog"></i> Auto</td>
                                    <td><i class="fa fa-road"></i> 25000</td>
                                 </tr>
                              </table>
                           </div>
                        </div>
                     </div>
                     <div class="swiper-slide">
                        <div class="thumbnail no-border no-padding thumbnail-car-card">
                           <div class="media">
                              <a class="media-link" data-gal="prettyPhoto" href="assets/img/preview/cars/car-370x220x2.jpg">
                              <img src="assets/img/preview/cars/car-370x220x2.jpg" alt=""/>
                              <span class="icon-view"><strong><i class="fa fa-eye"></i></strong></span>
                              </a>
                           </div>
                           <div class="caption text-center">
                              <h4 class="caption-title"><a href="contact.php">VW POLO TRENDLINE 2.0 TDI</a></h4>
                              <div class="caption-text">Start from 3200/per a day</div>
                              <div class="buttons">
                                 <a class="btn btn-theme" href="contact.php">Rent It</a>
                              </div>
                              <table class="table">
                                 <tr>
                                    <td><i class="fa fa-car"></i> 2013</td>
                                    <td><i class="fa fa-dashboard"></i> Diesel</td>
                                    <td><i class="fa fa-cog"></i> Auto</td>
                                    <td><i class="fa fa-road"></i> 25000</td>
                                 </tr>
                              </table>
                           </div>
                        </div>
                     </div>
                     <div class="swiper-slide">
                        <div class="thumbnail no-border no-padding thumbnail-car-card">
                           <div class="media">
                              <a class="media-link" data-gal="prettyPhoto" href="assets/img/preview/cars/car-370x220x1.jpg">
                              <img src="assets/img/preview/cars/car-370x220x1.jpg" alt=""/>
                              <span class="icon-view"><strong><i class="fa fa-eye"></i></strong></span>
                              </a>
                           </div>
                           <div class="caption text-center">
                              <h4 class="caption-title"><a href="contact.php">VW POLO TRENDLINE 2.0 TDI</a></h4>
                              <div class="caption-text">Start from 2500/per a day</div>
                              <div class="buttons">
                                 <a class="btn btn-theme" href="contact.php">Rent It</a>
                              </div>
                              <table class="table">
                                 <tr>
                                    <td><i class="fa fa-car"></i> 2013</td>
                                    <td><i class="fa fa-dashboard"></i> Diesel</td>
                                    <td><i class="fa fa-cog"></i> Auto</td>
                                    <td><i class="fa fa-road"></i> 25000</td>
                                 </tr>
                              </table>
                           </div>
                        </div>
                     </div>
                     <div class="swiper-slide">
                        <div class="thumbnail no-border no-padding thumbnail-car-card">
                           <div class="media">
                              <a class="media-link" data-gal="prettyPhoto" href="assets/img/preview/cars/car-370x220x4.jpg">
                              <img src="assets/img/preview/cars/car-370x220x4.jpg" alt=""/>
                              <span class="icon-view"><strong><i class="fa fa-eye"></i></strong></span>
                              </a>
                           </div>
                           <div class="caption text-center">
                              <h4 class="caption-title"><a href="contact.php">VW POLO TRENDLINE 2.0 TDI</a></h4>
                              <div class="caption-text">Start from 3000/per a day</div>
                              <div class="buttons">
                                 <a class="btn btn-theme" href="contact.php">Rent It</a>
                              </div>
                              <table class="table">
                                 <tr>
                                    <td><i class="fa fa-car"></i> 2013</td>
                                    <td><i class="fa fa-dashboard"></i> Diesel</td>
                                    <td><i class="fa fa-cog"></i> Auto</td>
                                    <td><i class="fa fa-road"></i> 25000</td>
                                 </tr>
                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- If we need navigation buttons -->
               <div class="swiper-button-next"><i class="fa fa-angle-right"></i></div>
               <div class="swiper-button-prev"><i class="fa fa-angle-left"></i></div>
            </div>
         </div>
         <!-- tab 3 -->
         <div class="tab-pane fade" id="tab-3">
            <div class="swiper swiper--offers-economic">
               <div class="swiper-container">
                  <div class="swiper-wrapper">
                     <!-- Slides -->
                     <div class="swiper-slide">
                        <div class="thumbnail no-border no-padding thumbnail-car-card">
                           <div class="media">
                              <a class="media-link" data-gal="prettyPhoto" href="assets/img/preview/cars/car-370x220x1.jpg">
                              <img src="assets/img/preview/cars/car-370x220x1.jpg" alt=""/>
                              <span class="icon-view"><strong><i class="fa fa-eye"></i></strong></span>
                              </a>
                           </div>
                           <div class="caption text-center">
                              <h4 class="caption-title"><a href="contact.php">VW POLO TRENDLINE 2.0 TDI</a></h4>
                              <div class="caption-text">Start from 3000/per a day</div>
                              <div class="buttons">
                                 <a class="btn btn-theme" href="contact.php">Rent It</a>
                              </div>
                              <table class="table">
                                 <tr>
                                    <td><i class="fa fa-car"></i> 2013</td>
                                    <td><i class="fa fa-dashboard"></i> Diesel</td>
                                    <td><i class="fa fa-cog"></i> Auto</td>
                                    <td><i class="fa fa-road"></i> 25000</td>
                                 </tr>
                              </table>
                           </div>
                        </div>
                     </div>
                     <div class="swiper-slide">
                        <div class="thumbnail no-border no-padding thumbnail-car-card">
                           <div class="media">
                              <a class="media-link" data-gal="prettyPhoto" href="assets/img/preview/cars/car-370x220x2.jpg">
                              <img src="assets/img/preview/cars/car-370x220x2.jpg" alt=""/>
                              <span class="icon-view"><strong><i class="fa fa-eye"></i></strong></span>
                              </a>
                           </div>
                           <div class="caption text-center">
                              <h4 class="caption-title"><a href="contact.php">VW POLO TRENDLINE 2.0 TDI</a></h4>
                              <div class="caption-text">Start from 4000/per a day</div>
                              <div class="buttons">
                                 <a class="btn btn-theme" href="contact.php">Rent It</a>
                              </div>
                              <table class="table">
                                 <tr>
                                    <td><i class="fa fa-car"></i> 2013</td>
                                    <td><i class="fa fa-dashboard"></i> Diesel</td>
                                    <td><i class="fa fa-cog"></i> Auto</td>
                                    <td><i class="fa fa-road"></i> 25000</td>
                                 </tr>
                              </table>
                           </div>
                        </div>
                     </div>
                     <div class="swiper-slide">
                        <div class="thumbnail no-border no-padding thumbnail-car-card">
                           <div class="media">
                              <a class="media-link" data-gal="prettyPhoto" href="assets/img/preview/cars/car-370x220x3.jpg">
                              <img src="assets/img/preview/cars/car-370x220x3.jpg" alt=""/>
                              <span class="icon-view"><strong><i class="fa fa-eye"></i></strong></span>
                              </a>
                           </div>
                           <div class="caption text-center">
                              <h4 class="caption-title"><a href="contact.php">VW POLO TRENDLINE 2.0 TDI</a></h4>
                              <div class="caption-text">Start from 2900/per a day</div>
                              <div class="buttons">
                                 <a class="btn btn-theme" href="contact.php">Rent It</a>
                              </div>
                              <table class="table">
                                 <tr>
                                    <td><i class="fa fa-car"></i> 2013</td>
                                    <td><i class="fa fa-dashboard"></i> Diesel</td>
                                    <td><i class="fa fa-cog"></i> Auto</td>
                                    <td><i class="fa fa-road"></i> 25000</td>
                                 </tr>
                              </table>
                           </div>
                        </div>
                     </div>
                     <div class="swiper-slide">
                        <div class="thumbnail no-border no-padding thumbnail-car-card">
                           <div class="media">
                              <a class="media-link" data-gal="prettyPhoto" href="assets/img/preview/cars/car-370x220x4.jpg">
                              <img src="assets/img/preview/cars/car-370x220x4.jpg" alt=""/>
                              <span class="icon-view"><strong><i class="fa fa-eye"></i></strong></span>
                              </a>
                           </div>
                           <div class="caption text-center">
                              <h4 class="caption-title"><a href="contact.php">VW POLO TRENDLINE 2.0 TDI</a></h4>
                              <div class="caption-text">Start from 3500/per a day</div>
                              <div class="buttons">
                                 <a class="btn btn-theme" href="contact.php">Rent It</a>
                              </div>
                              <table class="table">
                                 <tr>
                                    <td><i class="fa fa-car"></i> 2013</td>
                                    <td><i class="fa fa-dashboard"></i> Diesel</td>
                                    <td><i class="fa fa-cog"></i> Auto</td>
                                    <td><i class="fa fa-road"></i> 25000</td>
                                 </tr>
                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- If we need navigation buttons -->
               <div class="swiper-button-next"><i class="fa fa-angle-right"></i></div>
               <div class="swiper-button-prev"><i class="fa fa-angle-left"></i></div>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- playstore section -->
<section data-aos="zoom-in" data-aos-duration="950" data-aos-delay="100" data-aos-once="true">
   <div class="backimg img-responsive ">
      <h2>A CAR FOR EVERY NEED</h2>
      <p>We have range of cars, So something will perfectly fit your trip</p>
      <div class="app">
         <a href="https://play.google.com/store"><img src="assets/img/playstore.png"></a>
         <a href="https://itunes.apple.com/pw/genre/ios/id36?mt=8"><img src="assets/img/appstore.png"></a>
      </div>
   </div>
</section>

<!-- demo slider -->

<section class="con">
   <div class="seca" data-aos="slide-left" data-aos-duration="1350" data-aos-delay="50" data-aos-once="true">
      <div class="heading1">
                  <h2>Demo Sliders</h2>
               </div>
        <div class="row">
            <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12 slidee">
                <div class="carousel slide" data-ride="carousel" id="carousel-1">
                    <div class="carousel-inner" role="listbox">
                        <div class="item active">
                            <div class="jumbotron hero-nature carousel-hero"></div>
                        </div>
                        <div class="item">
                            <div class="jumbotron hero-photography carousel-hero"></div>
                        </div>
                        <div class="item">
                            <div class="jumbotron hero-technology carousel-hero"></div>
                        </div>
                        <div class="item">
                            <div class="jumbotron hero-technology1 carousel-hero"></div>
                        </div>
                        <div class="item">
                            <div class="jumbotron hero-technology2 carousel-hero"></div>
                        </div>
                        <div class="item">
                            <div class="jumbotron hero-technology3 carousel-hero"></div>
                        </div>
                        <div class="item">
                            <div class="jumbotron hero-technology4 carousel-hero"></div>
                        </div>
                    </div>
                    <div><a class="left carousel-control" href="#carousel-1" role="button" data-slide="prev"><i class="glyphicon glyphicon-chevron-left"></i><span class="sr-only">Previous</span></a><a class="right carousel-control" href="#carousel-1" role="button"
                            data-slide="next"><i class="glyphicon glyphicon-chevron-right"></i><span class="sr-only">Next</span></a></div>
                    <ol class="carousel-indicators">
                        <li data-target="#carousel-1" data-slide-to="0" class="active"></li>
                        <li data-target="#carousel-1" data-slide-to="1"></li>
                        <li data-target="#carousel-1" data-slide-to="2"></li>
                        <li data-target="#carousel-1" data-slide-to="3"></li>
                        <li data-target="#carousel-1" data-slide-to="4"></li>
                        <li data-target="#carousel-1" data-slide-to="5"></li>
                        <li data-target="#carousel-1" data-slide-to="6"></li>
                    </ol>
                </div>
            </div>
            <div class="col-lg-8 col-md-12 col-sm-12">
                <div>
                    <h1 class="heeadd">Show how&nbsp;great&nbsp;and&nbsp;easy&nbsp;it is to use.<br><span class="line"></span></h1>
                    <ul class="steplist">
                        <li class="listclass"><span class="step">Step 1</span>  Choose Either&Driver Service or Cab Service (Car Rental for Outstation).<br></li>
                        <li class="listclass"><span class="step">Step 2</span>  Enter your Destination and then choose type of Ride.<br></li>
                        <li class="listclass"><span class="step">Step 3</span>  You can choose type of vehicle and its availability in your location. You can go for ride now and ride later.<br></li>
                        <li class="listclass"><span class="step">Step 4</span>  Select Riding Date and Time </strong>.<br></li>
                        <li class="listclass"><span class="step">Step 5</span>  Confrim your booking<br></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section> 

<!--  tarrif details -->

<section class="con1">
   <div class="heading1">
                  <h2>Tarrif Details</h2>
               </div>
   <button class="tablink" onclick="openPage('Home', this, '#2b3574')" id="defaultOpen">Vehicles Details</button>
<button class="tablink" onclick="openPage('News', this, '#2b3574')" >Driver Charges</button>

<div id="Home" class="tabcontent">
    <table class="rwd-table">
               <thead>
                  <tr class="table100-head">
                     <th class="column1">TYPE OF VEHICLES WITH AC</th>
                     <th class="column2">4/40 HR & KM LOCAL</th>
                     <th class="column3">80/8 HR & KM LOCAL</th>
                     <th class="column4">EXTRA P/OVER LOCAL</th>
                     <th class="column5">EXTRA P/KM LOCAL</th>
                     <th class="column6">OUT STATION P/KM</th>
                     <th class="column7">DRIVER BATA</th>
                  </tr>
               </thead>
               <tbody>
                  <tr>
                     <td class="column1" data-th="vehicle">Hatch Back</td>
                     <td class="column2" data-th="km">700</td>
                     <td class="column3" data-th="km">1300</td>
                     <td class="column4" data-th="extra">125</td>
                     <td class="column5" data-th="extra">9</td>
                     <td class="column6" data-th="outstation">9</td>
                     <td class="column7" data-th="bata">300</td>
                  </tr>
                  <tr>
                     <td class="column1" data-th="vehicle">Etios</td>
                     <td class="column2" data-th="km">800</td>
                     <td class="column3" data-th="km">1500</td>
                     <td class="column4" data-th="extra">150</td>
                     <td class="column5" data-th="extra">15</td>
                     <td class="column6" data-th="outstation">10</td>
                     <td class="column7" data-th="bata">300</td>
                  </tr>
                <tr>
                     <td class="column1" data-th="vehicle">Qualis/Tav</td>
                     <td class="column2" data-th="km">1200</td>
                     <td class="column3" data-th="km">2000</td>
                     <td class="column4" data-th="extra">150</td>
                     <td class="column5" data-th="extra">11</td>
                     <td class="column6" data-th="outstation">11
                     </td>
                     <td class="column7" data-th="bata">300</td>
                  </tr>
                    <tr>
                     <td class="column1" data-th="vehicle">Toyota Innova</td>
                     <td class="column2" data-th="km">-</td>
                     <td class="column3" data-th="km">2500</td>
                     <td class="column4" data-th="extra">250</td>
                     <td class="column5" data-th="extra">13</td>
                     <td class="column6" data-th="outstation">13
                     </td>
                     <td class="column7" data-th="bata">300</td>
                  </tr>
                    <tr>
                     <td class="column1" data-th="vehicle">Toyota Crysta</td>
                     <td class="column2" data-th="km">-</td>
                     <td class="column3" data-th="km">3000</td>
                     <td class="column4" data-th="extra">250</td>
                     <td class="column5" data-th="extra">15</td>
                     <td class="column6" data-th="outstation">14
                     </td>
                     <td class="column7" data-th="bata">300</td>
                  </tr>
                    <tr>
                     <td class="column1" data-th="vehicle">Toyota Forturner</td>
                     <td class="column2" data-th="km">-</td>
                     <td class="column3" data-th="km">6000</td>
                     <td class="column4" data-th="extra">500</td>
                     <td class="column5" data-th="extra">35</td>
                     <td class="column6" data-th="outstation">30
                     </td>
                     <td class="column7" data-th="bata">400</td>
                  </tr>
                    <tr>
                     <td class="column1" data-th="vehicle">Mercedes Benz</td>
                     <td class="column2" data-th="km">-</td>
                     <td class="column3" data-th="km">15000</td>
                     <td class="column4" data-th="extra">1500</td>
                     <td class="column5" data-th="extra">50</td>
                     <td class="column6" data-th="outstation">50
                     </td>
                     <td class="column7" data-th="bata">500</td>
                  </tr>
                    <tr>
                     <td class="column1" data-th="vehicle">BMW</td>
                     <td class="column2" data-th="km">-</td>
                     <td class="column3" data-th="km">14000</td>
                     <td class="column4" data-th="extra">1300</td>
                     <td class="column5" data-th="extra">45</td>
                     <td class="column6" data-th="outstation">45
                     </td>
                     <td class="column7" data-th="bata">500</td>
                  </tr>
                    <tr>
                     <td class="column1" data-th="vehicle">Tempo Taveller</td>
                     <td class="column2" data-th="km">-</td>
                     <td class="column3" data-th="km">3000</td>
                     <td class="column4" data-th="extra">250</td>
                     <td class="column5" data-th="extra">15</td>
                     <td class="column6" data-th="outstation">15
                     </td>
                     <td class="column7" data-th="bata">400</td>
                  </tr>
                    <tr>
                     <td class="column1" data-th="vehicle">21 Seater</td>
                     <td class="column2" data-th="km">-</td>
                     <td class="column3" data-th="km">7000</td>
                     <td class="column4" data-th="extra">1000</td>
                     <td class="column5" data-th="extra">34</td>
                     <td class="column6" data-th="outstation">33
                     </td>
                     <td class="column7" data-th="bata">500</td>
                  </tr>
                    <tr>
                     <td class="column1" data-th="vehicle">35 Seater</td>
                     <td class="column2" data-th="km">-</td>
                     <td class="column3" data-th="km">10000</td>
                     <td class="column4" data-th="extra">1500</td>
                     <td class="column5" data-th="extra">46</td>
                     <td class="column6" data-th="outstation">45
                     </td>
                     <td class="column7" data-th="bata">700</td>
                  </tr>
                    <tr>
                     <td class="column1" data-th="vehicle">40 Seater Volvo A/C</td>
                     <td class="column2" data-th="km">Outstation Minimum 500Kms</td>
                     <td class="column3" data-th="km">15000</td>
                     <td class="column4" data-th="extra">2500</td>
                     <td class="column5" data-th="extra">65</td>
                     <td class="column6" data-th="outstation">62
                     </td>
                     <td class="column7" data-th="bata">1000</td>
                  </tr>

               </tbody>
            </table>
            <p>1. Meter reading starts from travels office and final reading ends at travel's office</p>
            <p>2. Min. 300kms/ Day should be cocovered or and equivalent amount for 300kms. Should be given.</p>
            <p>3. Driver Batta per day 6 am to 9 pm thereafter driving additional batta will be charged.</p>
            <p>4. Travel's office is not responsible for any lost property during the trip</p>
            <p>5. Day means calender day from 6.00am to 12.00pm.</p>
            <p>6. Booking for heacy vehicles please call for full details</p>
            <p>7. The final bill will be additional GST and all inclusive 10%</p>
</div>

<div id="News" class="tabcontent">
<ul class="driverlist">
   <li>
   Rs 230/- for 2 hours round trip.   
   </li>
   <li>Rs 396/- for 4 hours round trip. (all inclusive)</li>
   <li>After a regular slab of 2 and 4 hours Rs. 24.75/- thereafter for every additional 15 minutes. (all inclusive)</li>
   <li>Rs. 75/- extra to be paid for duty ending after 10.00 p.m. between 11 pm as slab A  (1)</li>
   <li>Rs. 75/- extra to be paid for duty ending after 11.00 p.m between 12 pm as slab A ( 2)</li>
   <li>Thereafter the rates will be charged Rs. 99/- per hour  till 4 am</li>
   <li>Rs. 75/- extra to be paid  before 6 am between 5 am as slab,  B (1)</li>
   <li>Rs  75/- extra to be paid Before 5 am between 4 am as slab,   B (2)</li>
   <li>Rs. 80/- extra to be paid if Pickup and Drop's Locations are different with a grace period of one hour to the driver</li>
   <li>Airport pickup or drop Additional Rs 50/- extra on a taken slab.</li>
   <li>Outstation duty: Starting from Rs. 1000/- per day 12hours depending on the destination ( Food + Accommodation ( if the duration is more than 1 days) late night and early morning charges will be as above slab A and  B.</li>
   <li>Outstations trip 111/- extra hours</li>
   <li>Outstations trip ending after 3 Am will be charged one day Rs 1000/- additional for the following day considering the safety and rest to a driver, taking precautions of other clients safety measurements also</li>
   <li>Rs 396/- 4 hours and Rs 24.75/- GST and service charge included.</li>
   <li>Cancellation of Rs 100/- has to be paid if the driver reaches your place</li>
   <li>The cancellation has to be done before one hour from the booking time </li>
   <p>  * Note.1, Travel Convenience will be applied for Local one-way service. Food Charges will be applied for outstation Service on per day basis</p>
   <p>Note.2,  GST of 18% and service charge of 5% is applicable  Payment done by clients such as cash or online, exclusive apart from From 4hours and the regular slab of 15 minutes</p>
   <p>Note.3, Final Bill will be Inclusive of GST</p>
</ul>
</div>
</section>

<!--   Testimonial   -->   
<section class="space">
   <div class="container-fluid" data-aos="zoom-in" data-aos-duration="950" data-aos-delay="100" data-aos-once="true">
      <div class="row">
         <h2 class="headingtesti">Client say about us</h2>
         <p class="paratesti">OUR HAPPY CLIENTS</p>
         <div class="col-md-12">
            <div class="col-sm-offset-1 col-sm-10">
               <div id="testimonial-slider" class="owl-carousel">
                  <div class="testimonial">
                     <p class="description">
                       I have been using Yogesh's DriveCare cabs since the time he started this business - for almost 3 years now. I have availed of both his taxi services and his on-call drivers. I use their services every working day; for my trips out of Bangalore and for visiting friends and relatives.
                     </p>
                     <ul class="stars-rating">
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                     </ul>
                     <div class="testimonial-review">
                        <div class="pic">
                           <img src="assets/img/img-1.jpg" alt="">
                        </div>
                        <h4 class="testimonial-title">
                           Z George
                           <small>Driver services</small>
                        </h4>
                     </div>
                  </div>
                  <div class="testimonial">
                     <p class="description">
                       A good and excellent service provider in sarjapur road locality availing service from since 3 years Mr.yogesh is oriented and focused on clients requirements and provides services responsibly even attending the calls in odd hours is appreciable with a short ring of mobile.good keep it up
                     </p>
                     <ul class="stars-rating">
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                     </ul>
                     <div class="testimonial-review">
                        <div class="pic">
                           <img src="assets/img/img-1.jpg" alt="">
                        </div>
                        <h4 class="testimonial-title">
                           Srinivas cheenu
                           <small>Driver services</small>
                        </h4>
                     </div>
                  </div>
                  <div class="testimonial">
                     <p class="description">
                        I have been using Drivecare services for the past 2 years. Yogesh has always been reliable and quick. He ensures that the drivers arrive on time. Another important point is, the drivers & Cabs are hygienic, well mannered and cooperative. When I have any feedback on the drivers, it is acted upon promptly. Overall it has been a pleasant experience with drivecare. Keep up the good work!!
                     </p>
                     <ul class="stars-rating">
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                     </ul>
                     <div class="testimonial-review">
                        <div class="pic">
                           <img src="assets/img/img-1.jpg" alt="">
                        </div>
                        <h4 class="testimonial-title">
                          Seetha
                           <small>Driver services</small>
                        </h4>
                     </div>
                  </div>
                  <div class="testimonial">
                     <p class="description">
                        I have been using the services of Drivecare for almost 2 years now. They have a team of extremely professional Drivers and cabs available at very reasonable rates. I have used their services for trips within Bangalore and Out-station as well and I am extremely pleased with their services. The drivers give utmost priority to the Safety and comfort of the customers which is really good.
                     </p>
                     <ul class="stars-rating">
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                     </ul>
                     <div class="testimonial-review">
                        <div class="pic">
                           <img src="assets/img/img-1.jpg" alt="">
                        </div>
                        <h4 class="testimonial-title">
                           Sudeep Divakaran
                           <small>Driver services</small>
                        </h4>
                     </div>
                  </div>
                  <div class="testimonial">
                     <p class="description">
                        I am always availing a temporary driver/cabs service through this service provider, they have been providing very punctual and flexible drivers. I am impressed with their service.
                     </p>
                     <ul class="stars-rating">
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                     </ul>
                     <div class="testimonial-review">
                        <div class="pic">
                           <img src="assets/img/img-1.jpg" alt="">
                        </div>
                        <h4 class="testimonial-title">
                          Raghava Ram se
                           <small>Driver services</small>
                        </h4>
                     </div>
                  </div>
                  <div class="testimonial">
                     <p class="description">
                        I take services from DriveCare  for my school. We have always got back up whenever the primary driver was on leave. Driver takes a minimum number of holidays. Yogesh, who owns the business has been prompt to solve any problem that I faced. I strongly recommend DriveCare.Cabs Pvt Ltd
                     </p>
                     <ul class="stars-rating">
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                        <li><i class="fa fa-star checked"></i></li>
                     </ul>
                     <div class="testimonial-review">
                        <div class="pic">
                           <img src="assets/img/img-1.jpg" alt="">
                        </div>
                        <h4 class="testimonial-title">
                           Abhilash
                           <small>Driver services</small>
                        </h4>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- Number Counter -->
<section class="page-section">
   <div class="container">
      <div class="counter" data-aos="zoom-in" data-aos-duration="950" data-aos-delay="100" data-aos-once="true">
         <div class="container">
            <div class="row">
               <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                  <div class="funfact">
                     <span><i class="flaticon-like"></i></span>
                     <div class="fun-meta">
                        <span class="counter-count">20</span>
                        <h5>user love Car Carry</h5>
                     </div>
                  </div>
               </div>
               <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                  <div class="funfact">
                     <span><i class="flaticon-road"></i></span>
                     <div class="fun-meta">
                        <span class="counter-count">4329</span>
                        <h5>rides made per day</h5>
                     </div>
                  </div>
               </div>
               <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                  <div class="funfact">
                     <span><i class="flaticon-favorites"></i></span>
                     <div class="fun-meta">
                        <span class="counter-count">321</span>
                        <h5>ratings made daily</h5>
                     </div>
                  </div>
               </div>
               <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                  <div class="funfact">
                     <span><i class="flaticon-user"></i></span>
                     <div class="fun-meta">
                        <span class="counter-count">100</span>
                        <h5>New Users Register Daily</h5>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<?php include("footer.php"); ?>