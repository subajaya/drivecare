<?php include("header.php"); ?>
<?php include("menu.php"); ?>
<!-- CONTENT AREA -->
<div class="content-area">
<!-- BREADCRUMBS -->
<section class="page-section breadcrumbs text-center">
   <div class="container">
      <div class="page-header">
         <h1>Privacy Policy</h1>
      </div>
      <ul class="breadcrumb">
         <li><a href="index.php">Home</a></li>
         <li class="active">Privacy Policy</li>
      </ul>
   </div>
</section>
<!-- /BREADCRUMBS -->
<div class="content-area">
   <div class="container padd-lr0">
      <div class="row">
         <div class="col-md-12" data-aos="zoom-in" data-aos-duration="950" data-aos-delay="100" data-aos-once="true">
            <div class="wheel-info-text  marg-lg-t150 marg-lg-b150 marg-md-t100 marg-md-b100 marg-sm-t50 marg-sm-b50">
               <div class="wheel-header">
                  <h3>Privacy Policy</h3>
               </div>
            <p>This privacy policy sets out how Drivecare uses and protects any information that you give Drivecare when you use this Website/Application.</p>

   <p>Drivecare is committed to ensuring that your privacy is protected.
Should we ask you to provide certain information by which you can be identified when using this Website/Application, and then you can be assured that it will only be used in accordance with this privacy statement.
</p>
   <p>Drivecare may change this policy from time to time by updating this page. You should check this page from time to time to ensure that you are happy with any changes.</p>
<h4 class="hh">INFORMATION THAT IS OR MAY BE COLLECTED FROM YOU</h4>

   <p>We may collect the following information:</p>

   <p>name and job title;</p>

   <p>contact information including email address;</p>
   <p>information about your mobile device that allows us to uniquely identify you</p>
   <p>demographic information such as postcode, preferences and interests;</p>
   <p>information relevant to customer surveys and/or offers;</p>
   <p>Geo-location;</p>
   <p>financial information (like account or credit card numbers);</p>

   <p>opinions of features on this Website/Application; and</p>
   <p>Other information as per our registration process.</p>

   <p>We may also collect the following information:</p>

   <p>about the pages you visit/access;</p>

   <p>the links you click on this Website;</p>

   <p>the number of times you access a particular page; and</p>

   <p>the number of times you have interacted on this Website.</p>

   <h4 class="hh">WHAT WE DO WITH THE INFORMATION WE GATHER</h4>

   <p>We require this information to understand your needs and provide you with a better service, and in particular for the following reasons:</p>

   <p>Internal record keeping;</p>

   <p>We may use the information to improve our Services;</p>

   <p>We may periodically send promotional emails, SMSs or push notifications about new products, special offers or other information which we think you may find interesting using the email address which you have provided; and From time to time, we may also use your information to contact you for market research purposes. We may contact you by email, phone, fax or mail. We may use the information to customize the Website/Application according to your interests.</p>

   <h4 class="hh">SECURITY</h4>

   <p>We are committed to ensuring that your information is secure. In order to prevent unauthorized access or disclosure we have put in place suitable physical, electronic and managerial procedures to safeguard and secure the information we collect online.</p>
    <h4 class="hh">ACCOUNT SECURITY</h4>





   <p>You are solely responsible for the confidentiality of any password and other account information that you create in order to access or use the Website/ Application. You agree to notify us immediately on any unauthorized use of your account, user name, or password. You also agree that Drivecare is not liable in any manner for any loss that you may incur as a result of any third party using your password, either with or without your knowledge. You are solely liable for any losses incurred by us, our affiliates, officers, directors, employees, consultants, agents, and representatives due to misuse of your account or password. You will not under any circumstances use the account, username, or password of someone else at any time.</p>

   <h4 class="hh">PROHIBITED USES:</h4>

   <p>You are prohibited from violating or attempting to violate any security features of any of our Website/ Application, including, without
limitation: (a) accessing content or data not intended for you, or logging onto a server or account that you are not authorized to access;
(b) attempting to probe, scan, or test the vulnerability of any of our Website/ Application or any associated services, system or network, or to breach security or authentication measures without proper authorization; (c) using any automated process or service (such as, by way of example only, any spider, robot, or automated searching or "scraping" tool) to monitor, access or copy any content from any Website/Application; (d) interfering or attempting to interfere with service to any user, host, or network, including, without limitation, by means of submitting a virus to the Website/Application, overloading, initiating or facilitating any "denial of service" attack, "flooding,"
"spamming," "mail bombing," or "crashing;" (e) using any our Website/ Application or servers to send unsolicited e-mail, including, without limitation, promotions, or advertisements for products or services; (f) forging any TCP/IP packet header or any part of the header information in any e-mail or in any posting using any our Website/ Application; or
(g) attempting to modify, reverse-engineer, decompile, disassemble, or otherwise reduce or attempt to reduce to a human-perceivable form any of the source code used by Drivecare in providing the Website/ Application or our Services. Any violation of system or network security may subject you to civil and/or criminal liability, and will result in a loss of your ability to access and use the Website/Application.

</p>
   <h4 class="hh">DEBIT / CREDIT CARD DETAILS</h4>

   <p>You agree, understand and confirm that the credit card details provided by you for registering as this Website/ Application will be correct and accurate and you shall not use the credit card which is not lawfully owned by you. You further agree and undertake to provide the correct and valid credit card details to us. Further, the said information will not be utilized and shared by us with any of the third parties unless required by law, regulation or court order.</p>

   <h4 class="hh">HOW WE USE COOKIES</h4>

   <p>A cookie is a small file which asks permission to be placed on your computer's hard drive. Once you agree, the file is added and the cookie helps analyse web traffic or lets you know when you visit a particular site. Cookies allow web applications to respond to you as an individual.
The web application can tailor its operations to your needs, likes and dislikes by gathering and remembering information about your preferences.
</p>

   <p>We use traffic log cookies to identify which pages are being used. This helps us analyse data about webpage traffic and improve our website in order to tailor it to customer needs. We only use this information for statistical analysis purposes and then the data is removed from the system.</p>

   <p>Overall, cookies help us provide you with a better Website/Application, by enabling us to monitor which pages you find useful and which you do not. A cookie in no way gives us access to your computer or any information about you, other than the data you choose to share with us.</p>

   <p>You can choose to accept or decline cookies. Most web browsers automatically accept cookies, but you can usually modify your browser setting to decline cookies if you prefer. This may prevent you from taking full advantage of the website.</p>

   

   <h4 class="hh">LINKS TO OTHER WEBSITES</h4>

   <p> Our Application /Website may contain links to other websites of interest. However, once you have used these links to leave our site, you should note that we do not have any control over that other website.
Therefore, we cannot be responsible for the protection and privacy of any information which you provide whilst visiting such sites and such sites are not governed by this privacy statement. You should exercise caution and look at the privacy statement applicable to the website in question.
</p>
    <p>We will not sell, distribute or lease your personal information to third parties unless we have your permission or are required by law to do so.
We may use your personal information to send you promotional information about third parties which we think you may find interesting if you tell us that you wish this to happen.

</p>
   
   <p>Notwithstanding the above, we confirm that we shall at all times be in full compliance with the Information Technology (Reasonable security practices and procedures and sensitive personal data or information) Rules, 2011.</p>

                  <h3 class="ha">Refund and Cancellation Policy</h3>
                  <h1 class="hh">CANCELLATION AND REFUND: DRIVER HIRE</h1>
                  <p>Bookings canceled within 30 minutes of making the booking will not be charged, bookings canceled after 30 minutes of booking will incur a nominal cancellation charge of Rs.100/-.

            <br>Refund since we are a service provider we cannot offer any refunds for services consumed.</p>
                <h1 class="hh">CANCELLATION AND REFUND: Car Rental | Cab Hire</h1>
                        <p>
                           You may cancel the booking 24 hours prior to the time of the journey, without any cancellation charges for all services. In case cancellation or shorting of the trip is requested within 24 hours of the pick-up time, the following rules will apply:
                           <p></p>
                        <p>Multi-Day trip: The charge for the first day would be deducted from the total amount and refund will be issued to the user.</p>
                        <p>Single Day trip/ Airport transfer: No Refund will be issued to the user.</p>
                        <p>Airport transfer: No Cancellation Charges if Canceled at least 2 hours prior to pickup time.</p>
                        <p>Refunds<br>
If you are eligible for refunds based on the "Cancellation and Returns" policy above, then the refund will be remitted back to you in 5-7 working days. In case of any issues, write to us at drivecare@yoge@gmail.com or call us at 9066931919 </p>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- /CONTENT AREA -->
<?php include("footer.php"); ?>