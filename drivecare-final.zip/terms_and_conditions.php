<?php include("header.php"); ?>
<?php include("menu.php"); ?>
<!-- CONTENT AREA -->
<div class="content-area">
<!-- BREADCRUMBS -->
<section class="page-section breadcrumbs text-center">
   <div class="container">
      <div class="page-header">
         <h1>Terms and Conditions</h1>
      </div>
      <ul class="breadcrumb">
         <li><a href="index.php">Home</a></li>
         <li class="active">Terms and Conditions</li>
      </ul>
   </div>
</section>
<!-- /BREADCRUMBS -->
<div class="content-area">
   <div class="container padd-lr0">
      <div class="row">
         <div class="col-md-12" data-aos="zoom-in" data-aos-duration="950" data-aos-delay="100" data-aos-once="true">
            <div class="wheel-info-text  marg-lg-t150 marg-lg-b150 marg-md-t100 marg-md-b100 marg-sm-t50 marg-sm-b50">
               <div class="wheel-header">
                  <h3>Terms & Conditions</h3>
               </div>
   <p>Welcome to our mobile application and / or our website.</p>

   <p>These terms and conditions of use (‘’Terms of Use’’) of the
Drivecare website and mobile app, is a legal agreement ("Agreement")
Techtilt technologies  Pvt. Ltd.  Mobile App developer,  firm registered
under the laws of India having its offices at  your full address,
Tamilnadu  and yourself/yourselves. If you continue to browse the
website and/or use the mobile application you are agreeing to comply
with and be bound by the Terms of Use.

</p>
   <p>If you do not agree with the Terms of Use, please do not access and use
this Website / Application (as hereinafter defined).
</p>
   
    <h4 class="hh">DEFINITIONS:</h4>
   <p>“You”, yourself / yourselves and “your” shall mean a User, who
meets the eligibility criteria set out below;
</p>
   <p>“Application” shall mean the application supplied by Drivecare and
downloaded and installed by you on your single mobile device (smart
phone);
</p>
   <p>“Driver” or ‘’Drivers’’ shall mean the driver engaged by you
by using our Website/Application;
</p>
   <p>“Force Majeure” shall have the meaning as set out in Clause VII;</p>
   <p>“Service” or “Services” shall mean the service of providing
short-term private Driver solutions via the Application/Website as
defined in Clause I;
</p>
   <p>‘’User’’ or ‘’Users’’ shall have the meaning as set out
in Clause III; and
</p>
   <p>‘’Website’’ shall mean the website www.drivecarecabs.in [2]</p>
   <p>These Terms of Use may be modified from time to time in our sole
discretion. It is your responsibility to review these Terms and
Conditions from time to time. If you continue to use the Service after
notice of change has been intimated or published on our
Website/Application, you thereby provide your consent to the changed
practices on the same terms hereof. For this reason, we encourage you to
review these Terms of Use each time you access and use the
Website/Application. Most content and some of the features on the
Website/Application are made available to Users free of charge. However,
Drivecare reserves the right to terminate access to certain areas or
features of the Website/Application at any time for any reason, with or
without notice.
</p>
   <p>If you are not agreeable to these Terms of Use, you may not use the
Services, the Website or the Application.
</p>
    <h4 class="hh">SERVICES DESCRIPTION:</h4>
   <p>Drivecare provides a technology based service which enables the hiring
of drivers by commuters/ passengers for a point to point pick up and
drop off Service, within city limits and outside city limits, through
the Application in mobile telecommunications devices and through the
Website. The Service is designed to offer you information and a means of
obtaining short-term private driver solutions to coordinate
point-to-point and round trip private driver services, at your request.
As a User, you authorize Drivecare to operate your vehicle and make
decisions on your behalf during a period of time designated by you.
</p>
    <h4 class="hh">USE OF SERVICE, APPLICATION AND WEBSITE:</h4>

   <p>The Application and the Website allows you to send a request for Service
to a Driver. The GPS receiver, which should be installed on the mobile
device (smart phone) on which you have downloaded the Application or the
Website, shall detect your location and shall send your location
information to the relevant Driver. Drivecare has sole and complete
discretion to accept or reject each request for providing the Service.
Drivecare also has sole and complete discretion over whether to use the
Application / Website to receive the leads generated through the
Application / Website. If Drivecare accepts a request, the Application /
Website notifies you and provides information regarding the Driver -
including his name and the ability to contact the Driver by telephone or
a message. The Application / Website also allow you to view the
Driver’s progress towards the pick-up point, in real time.
</p>
   <p>Drivecare shall undertake commercially reasonable efforts to bring you
into contact with a Driver in order to avail the Services, subject to
the availability of Drivers in or around your location at the moment of
your request for the Services.
</p>
   <p>Drivecare itself does not provide transportation services. It is up to
the User to offer transportation. Drivecare only acts as intermediary
between the Driver and you. The provision of the Services by the Driver
to you is, therefore, subject to the agreement (to be) entered into
between the Driver and you. Drivecare shall under no circumstance be a
party to such agreement. Drivecare disclaims any and all liability in
respect of the Drivers including any claims of employment or any
vicarious liability arising out of the Service or otherwise.
</p>
     <h4 class="hh">USER ELIGIBILITY AND AGREEMENT:</h4>
   <p>User means any individual or business entity/organization that legally
operates in India or in other countries, and uses and has the right to
use the Services provided by Drivecare. Our Services are available only
to those individuals or entities who can execute legally binding
contracts under the applicable law. Therefore, a User must not be a
minor as per Indian Law; i.e. User(s) must be at least 18 years of age
to be eligible to use our Services.
</p>
   <p>Drivecare advises its Users that while accessing the
Website/Application, they must follow/abide by the applicable laws.
Drivecare may, in its sole discretion, refuse the Service to anyone at
any time.
</p>
   <p>This Agreement applies to all Services offered on the
Website/Application, collectively with any additional terms and
condition that may be applicable.
</p>

 <h4 class="hh">REGISTRATION:</h4>
   <p>To use the Services, you have to be registered and provide your name,
contact number, email address and other details. Please see our Privacy
Policy and practices to know more about how your personal information
would be used.
</p>

  <h4 class="hh">REPRESENTATIONS AND WARRANTIES:</h4>
   <p>As a precondition to your use of the Services, you represent and warrant
that:
</p>
   <p>You will only access the Service using authorized means. You are
responsible to check and ensure you download the correct Application for
your device or the correct Website in your computer. Drivecare shall not
be liable if you do not have a compatible mobile device or if you
download the wrong version of the Application for your mobile device or
Website for the computer. Drivecare reserves the right to terminate the
Service and the use of the Application/ Website should you use the
Service or Application with an incompatible or unauthorized device.
</p>
   <p>You have the legal right and authority to possess and operate the
vehicle when engaging our Services and you confirm, represent and
warrant that the said vehicle is in good operating condition and meets
the industry safety standards and all applicable statutory requirements
for a motor vehicle of its kind.
</p>
   <p>You will be solely responsible for any and all liability which results
from or is alleged as a result of the condition of your vehicle, legal
compliance, etc., including, but not limited to, personal injuries,
death and property damages.
</p>
   <p>You will be solely responsible for the full functionality of your
vehicle. If your vehicle fails to function (electrical, mechanical or
other) in any way while the Services are being availed of by you, you
will be responsible for all storage fees, roadside assistance, alternate
transportation and repair of any kind and Drivecare nor the Driver shall
be responsible in any manner whatsoever. You have the legal right to
designate the Driver as your agent and delegate actual authority to the
Driver to operate your vehicle and make decisions on your behalf for the
purposes of providing Services offered through the Drivecare platform.
</p>
   <p>You are named or scheduled on the insurance policy covering the vehicle
you use when engaging our Services.
</p>
   <p>You have a valid policy of liability insurance (in coverage amounts
consistent with all applicable legal requirements) for the operation of
your vehicle to cover any anticipated losses related to your
participation in the Services or the operation of your vehicle by the
Driver. In the event of a motor vehicle accident you will be solely
responsible for compliance with any applicable statutory or department
of motor vehicles requirements and for all necessary contacts with your
insurance provider. Other than any personal criminal liability attaching
to the Driver you will be solely responsible for all consequences
arising out of the use of the Service or the Driver. In any event
Drivecare shall have no responsibility or liability on this account
whatsoever.
</p>
   <p>You specifically authorize us to use, store or otherwise process your
'Sensitive personal data or information’ (as such term is defined in
Information Technology (Reasonable security practices and procedures and
sensitive personal data or information) Rules, 2011) in order to provide
the Services to you. Subject to applicable law all information provided
to us by you shall be deemed to be our information to use as we desire.
</p>
   <p>You will obey all applicable laws related to the matters set forth
herein, and will be solely responsible for any violations of the same.
</p>
<h4 class="hh">METER START AND CANCELLATION POLICY:</h4>
   <p>Drivecare drivers will wait no more than 15 minutes from the requested
trip start time, before they start the trip timer.
</p>
   <p>You may cancel the booking within 30 minutes prior to the time of
journey, without any cancellation charges for all Services. The customer
is liable for Rs 100/- charge if the trip is cancelled thereafter.
</p>
   <h4 class="hh">PAYMENT</h4>
   <p>When a trip ends, Drivecare driver ends the trip on the Drivecare
Partner app on his mobile device. It then calculates the total fare
amount due from You and it appears on the Drivecare app on your mobile
device. You may pay the amount via cash or a variety of online payment
options available on the app including payment via the Drivecare Wallet
where You may have already pre-loaded funds. The usage of the Drivecare
Wallet shall be subject to the terms and conditions of the third party
payment processor providing the mobile payment service on the App. Any
payment related issue, except when such issue is due to an error or
fault in the Site or Application, shall be resolved between You and the
payment processor. Drivecare shall not be responsible for any
unauthorized use of Your Drivecare Wallet.
</p>
<h4 class="hh">LIMITATION OF LIABILITY:</h4>

<p>The information, recommendations and/or Services provided to you on or
through the Website/Application are for general information purposes
only and do not constitute advice. Drivecare will take reasonable steps
to keep the Website/Application and its contents correct and up to date
but does not guarantee that the contents of the Website/Application are
free of errors, defects, malware and viruses or that the
Website/Application are correct, up to date and accurate.
</p>
<p>Drivecare shall not be liable for any damages resulting from the use of,
or inability to use, the Website/Application, including damages caused
by malware, viruses or any incorrectness or incompleteness of the
information on the Website/Application.
</p>
<p>Drivecare shall further not be liable for damages resulting from the use
of, or the inability to use, electronic means of communication with the
Website/Application, including — but not limited to — damages
resulting from failure or delay in delivery of electronic
communications, interception or manipulation of electronic
communications by third parties or by computer programs used for
electronic communications and transmission of viruses.
</p>
<p>Without prejudice to the foregoing, and insofar as allowed under
mandatory applicable law, Drivecare’s aggregate liability shall in no
event exceed the equivalent of the amount for the payment of the
Services.
</p>
<p>The quality of the Services requested through the use of the Application
is entirely the responsibility of the Driver who ultimately provides
such transportation services to you. Drivecare under no circumstance
accepts liability in connection with and/or arising from the Services
provided by the Driver or any acts, actions, behaviour, conduct, and/or
negligence on the part of the Driver.
</p>
<p>We shall not be held liable for any failure or delay in performing
Services where such failure arises as a result of any act or omission,
which is outside our reasonable control such as unprecedented
circumstances, overwhelming and unpreventable events caused directly and
exclusively by forces of nature that can be neither anticipated, nor
controlled, nor prevented by the exercise of prudence, diligence, and
care, including but not limited to: war, riot, civil commotion;
compliance with any law or governmental order, rule, regulation or
direction and acts of third parties ( “Force Majeure” ).
</p>
<p>If we have contracted to provide identical or similar Service to more
than one User and are prevented from fully meeting our obligations to
you by reason of an event of Force Majeure, we may decide at our
absolute discretion which booking we will fulfil by providing the
Service, and to what extent.
</p>
<p>We have taken all reasonable steps to prevent internet fraud and ensure
any data collected from you is stored as securely and safely as
possible. However, we shall not be held liable in the unlikely event of
a breach in our secure computer servers or those of third parties other
than as required under applicable law.
</p>
<p>In the event we have a reasonable belief that there exists an abuse of
vouchers and/or discount codes or suspect an instance of fraud, we may
cause the User to be blocked immediately and reserve the right to refuse
future Service. Additionally, should there exist an abuse of vouchers or
discount codes, Drivecare reserves the right to seek compensation from
any and all such Users.
</p>
<p>Drivecare does not represent or endorse the accuracy or reliability of
any information, or advertisements (collectively, the "Content")
contained on, distributed through, or linked, downloaded or accessed
from or contained on the Website/Application, or the quality of any
products, information or other materials displayed, or obtained by you
as a result of an advertisement or any other information or offer in or
in connection with the Service.
</p>
<p>Offers are subject to Drivecare's discretion and may be withdrawn at any
time and without notice.
</p>
<h4 class="hh">INTELLECTUAL PROPERTY RIGHTS:</h4>


<p>Drivecare is the sole owner or lawful licensee of all the rights to the
Website/Application and its content. Website/Application content means
its design, layout, text, images, graphics, sound, video etc. The
Website/Application content embodies trade secrets and intellectual
property rights protected under worldwide copyright and other laws. All
title, ownership and intellectual property rights in the
Website/Application and its content shall remain with Drivecare.
</p>
<p>All rights, not otherwise claimed under this Agreement or in the Website
/Application, are hereby reserved. The information contained in this
Website/Application is intended, solely to provide general information
for the personal use of the reader, who accepts full responsibility for
its use.
</p>
<p>You may access the Website/Application, avail of the features,
facilities and Services for your personal or internal requirements only.
You are not entitled to duplicate, distribute, create derivative works
of, display, or commercially exploit the Website/Application Content,
features or facilities, directly or indirectly, without our prior
written permission of Drivecare.
</p>


<p>Copyright</p>
<p>All content on this Website/Application is the copyright of Drivecare
except the third party content and link to third party website on our
Website/Application, if any.
</p>
<p>Systematic retrieval of Drivcare content to create or compile, directly
or indirectly, a collection, compilation, database or directory (whether
through robots, spiders, automatic devices or manual processes) without
written permission from Drivecare is prohibited.

</p>
<p>In addition, use of the content for any purpose not expressly permitted
in this Terms of Use is prohibited and may invite legal action. As a
condition of your access to and use of Services, you agree that you will
not use the Website/Application to infringe the intellectual property
rights of others in any way. Drivecare reserves the right to terminate
the account of a User upon any infringement of the rights of others in
conjunction with use of the Service, or if Drivecare believes that
User’s conduct is harmful to the interests of Drivecare, its
affiliates, or other Users, or for any other reason in Drivecare's sole
discretion, with or without cause.
</p>
<h4 class="hh">USER ACCOUNTS, OFFERS AND PROMOTIONS:</h4>

<p>Drivecare reserves the right to collect User data including name,
contact information and other details to facilitate Services or use of
its platform to avail Services. All information collected from the User
are on a bona fide basis. Misuse and misrepresentation of identity or
contact details will lead to automatic termination of Services or the
use of the platform, without prior notice to such Users.
</p>
<p>User accounts bearing contact number and email IDs are created and owned
by Drivecare. Any promotional discounts and offers accumulated can be
revoked without prior notice in the event of suspicious account activity
or mala fide intent of the User.
</p>
<p>In the case where the system is unable to establish unique identity of a
User against a valid mobile number or e-mail ID, the account shall be
indefinitely suspended. Drivecare reserves the full discretion to
suspend a User's account in the above event and does not have the
liability to share any account information whatsoever.
</p>
<h4 class="hh">LINKS TO THIRD PARTY SITES:</h4>

<p>Links to third party sites are provided by the Application / Website as
a convenience to Users and Drivecare does not have any control over such
sites i.e., content and resources provided by them.
</p>
<p>Drivecare may allow Users access to content, products or services
offered by third parties through hyperlinks (in the form of word link,
banners, channels or otherwise) to such third party's website. You are
cautioned to read such sites' terms and conditions and/or privacy
policies before using such sites in order to be aware of the terms and
conditions of your use of such sites. The Users acknowledge that
Drivecare has no control over such third party's site, does not monitor
such sites, and Drivecare shall not be responsible or liable to anyone
for such third party site, or any content, products or services made
available on such a site.
</p>
<h4 class="hh">TERMINATION:</h4>
<p>Drivecare reserves the right to deny access to particular Users to
any/all of its Services without any prior notice/explanation in order to
protect the interests of Drivecare and/or other Users to the
Website/Application. Drivecare reserves the right to limit, deny or
create different access to the Website/Application and its features with
respect to different Users.
</p>
<p>We reserve the right to terminate your account or your access to the
Website/Application immediately, with or without notice to you, and
without liability: (i) if you have violated any of the Terms of Use;
(ii) if you have furnished us with false or misleading information;
(iii) pursuant to requests by law enforcement or other government
agencies; (iv) in case of unexpected technical or security issues or
problems; (v) in case of discontinuance or material modification to the
Services (or any part thereof); and / or (vi) in case of interference
with use of our Website/Application by others.
</p>
<p>In the event of termination by you or us, your account will be disabled
and you will not be granted access to your account or any information or
content contained in your account. You will not and not attempt to
create another account for accessing and using the Website/Application
without the written consent of Drivecare.
</p>
<p>This Terms of Use shall remain in full force and effect while you have
an account with us. Even after termination of your account with us,
certain provisions of this Terms of Use will remain in effect, including
but not limited to, Intellectual Property Rights, Prohibited Uses and
Indemnification. You agree that we will not be liable to you or any
third party for taking any of these actions.
</p>
<p>Notwithstanding the termination of this Agreement, you shall continue to
be bound by the terms of this Agreement in respect of your prior use of
this Website/Application and all matters connected with, relating to or
arising from such use.
</p>
<h4 class="hh">TERMS & CONDITIONS FOR USE OF SERVICES:</h4>
<p>The following terms & conditions shall apply to Users utilising the
Services offered by Drivecare:
</p>
<p>The User shall pay the driver fare (as displayed in the Drivecare App)
or as agreed to in the terms of use as listed on the Application /
Website, parking charges, additional night surcharge (where applicable),
one way trips, toll charges and any fee or levy presently payable or
hereinafter imposed by the law or required to be paid for availing of
the Services.
</p>
<p>The User agrees and accepts that the use of the Services provided by
Drivecare is at the sole risk of the User, and further acknowledges that
Drivecare disclaims all representations and warranties of any kind,
whether express or implied. All Services are provided “AS IS”.
</p>
<p>The Drivecare or the Driver has the right to refuse the Service in the
following circumstances:
</p>
<p>if the User is found to be in an intoxicated state or is found
misbehaving with other passengers or the Driver, or is causing a
nuisance;
</p>
<p>if the User is misusing, soiling or damaging any of the devices
(technical/non-technical) of the Driver; and if the User asks the Driver
to break any traffic/RTO/city police and/or government rules for any
purpose The Driver has the right to refuse such a request by the User
</p>
<p>Without prejudice to the above, Drivecare makes no representation or
warranty that:
</p>
<p>the Services will meet the User’s requirements; and the Services will
be uninterrupted, timely, secure, or error-free.
</p>
<p>The information on this Website/Application is provided "AS IS" with no
guarantee of completeness, accuracy, timeliness or of the results
obtained from the use of this information, and without warranty of any
kind, express or implied, including, but not limited to warranties of
performance, merchantability and fitness for a particular purpose.
Nothing herein shall to any extent substitute for the independent
investigations and the sound technical and business judgment of the
Users. In no event shall Drivecare be liable for any direct, indirect,
incidental, punitive, or consequential damages of any kind whatsoever
with respect to the Service. Users of this site must hereby acknowledge
that any reliance upon any content shall be at their sole risk. If any
User misses his/her train or flight or bus, Drivecare will not be liable
for any compensation.
</p>
<h4 class="hh">INSURANCE AND DAMAGE TO PROPERTY:</h4>
<p>We do not procure insurance for, nor are we responsible for, damage or
loss of any personal belongings or intellectual property whilst
providing the Services. These include tapes, records, discs or other
similar audio visual or data electronic devices, any speed measuring
equipment within the vehicle or any other accessories of any kind. It is
your responsibility to ensure that you remove any personal belongings
from the car before and after each Drivecare service arranged through
Drivecare.
</p>
<h4 class="hh">INDEMNITY:</h4>
<p>The User shall defend, indemnify and hold, Drivecare, its affiliates,
its licensors, and each of their officers, directors, other users,
employees, attorneys and agents, harmless, from and against any and all
claims, costs, damages, losses, liabilities and expenses (including
attorneys' fees and costs) arising out of or in connection with the:
</p>
<p>violation or breach of the Terms of Use or any applicable law or
regulation, whether or not referenced herein; violation of any rights of
any third party, including the Driver via the Application and or the
Website; and use or misuse of the Application/Website or Service.
</p>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- /CONTENT AREA -->
<?php include("footer.php"); ?>